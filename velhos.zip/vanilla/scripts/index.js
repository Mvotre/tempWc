{
  "colaboradores": [
      {
          "id": "2",
          "nome": "Antonio Henrique Carelli Netto",
          "login": "antonio.carelli@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "3",
          "nome": "Guilherme Viana",
          "login": "guilherme.viana@redeancora.com.br",
          "statusDescricao": "INATIVO",
          "status": "true"
      },
      {
          "id": "4",
          "nome": "Jonatas de Moraes Junior",
          "login": "jonatas.moraes@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "5",
          "nome": "Rafael Busuth",
          "login": "rafael.busuth@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "6",
          "nome": "Denis Colli Spalenza",
          "login": "denis.spalenza@redeancora.com.br",
          "statusDescricao": "INATIVO",
          "status": "true"
      },
      {
          "id": "7",
          "nome": "Rubia Gomes",
          "login": "rubia.gomes@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "8",
          "nome": "Luis Marin",
          "login": "luis.marin@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "9",
          "nome": "Antonio Neto",
          "login": "antonio.neto@redeancora.com.br",
          "statusDescricao": "INATIVO",
          "status": "true"
      },
      {
          "id": "10",
          "nome": "Rodrigo Nobrega da Silva",
          "login": "rodrigo.nobrega@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "11",
          "nome": "Leonardo Gutierrez",
          "login": "leonardo.gutierrez@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "12",
          "nome": "Thiago Lima",
          "login": "thiago.lima@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "13",
          "nome": "Thais Alves",
          "login": "thais.alves@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "14",
          "nome": "José Augusto",
          "login": "gestor@redeancora.com.br",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "15",
          "nome": "Colaborador de Teste",
          "login": "colaborador1@gmail.com",
          "statusDescricao": "NOVO",
          "status": "true"
      },
      {
          "id": "16",
          "nome": "Colaborador de Teste",
          "login": "colaborador2@gmail.com",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "17",
          "nome": "João Teste Boas Práticas",
          "login": "joao",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "18",
          "nome": "Maria Teste Boas Práticas",
          "login": "maria",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "19",
          "nome": "José Teste Boas Práticas",
          "login": "jose",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "20",
          "nome": "Carla Teste Boas Práticas",
          "login": "carla",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "21",
          "nome": "Neusa Teste Boas Práticas",
          "login": "neusa",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "22",
          "nome": "Joana Teste Boas Práticas",
          "login": "joana",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "23",
          "nome": "Mário Teste Boas Práticas",
          "login": "mario",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "24",
          "nome": "Leonardo Teste Boas Práticas",
          "login": "leonardo",
          "statusDescricao": "ATIVO",
          "status": "true"
      },
      {
          "id": "1",
          "nome": "Administrador",
          "login": "admin",
          "statusDescricao": "ATIVO",
          "status": "true"
      }
  ]
}